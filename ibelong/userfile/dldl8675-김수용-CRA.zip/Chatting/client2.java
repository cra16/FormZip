package Chatting;

import java.net.Socket;

public class client2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

		if(args.length != 1) //무슨의미냐 이건
		{
			System.out.println("input name!");
			return ;
		}
		
		
		try{
			Socket socket = new Socket("172.17.204.18",10004);
			Thread thread1 =  new SenderThread(socket, args[0]);
			Thread thread2 =  new ReceiverThread(socket);
			thread1.start();
			thread2.start();
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

}
