package Chatting;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.net.Socket;
//이걸 완벽히 이해하자 이게 클라이언트 저장맵의기능을 한다 
public class PerClientThread extends Thread{
	static List<PrintWriter>list = Collections.synchronizedList(new ArrayList<PrintWriter>()) ;  //이문장 이해가지 않는
	
	Socket socket;
	
	PrintWriter writer;
	public PerClientThread(Socket socket)   //생성자로 사용되는건지??? 아.. 걍메서드인
	{
		this.socket = socket;
		
		try
		{
			writer = new PrintWriter(socket.getOutputStream());
			list.add(writer);
			
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		
	
	}

	public void run()
	{
		String name = null;
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			name = reader.readLine();
			sendAll("#"+name+" is joined"); //알아보자
		while(true)
		{
			String str = reader.readLine();
			if(str == null)
				break;
			
			sendAll(name+">"+str);
		}
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}finally
		{
			list.remove(writer);
			sendAll("#"+name+"is out");
			try
			{
				socket.close();
			}catch(Exception ignored){}
		}
	}
	
	private void sendAll(String str)
	{
		for(PrintWriter writer: list)
		{
			writer.println(str);
			writer.flush();
		}
	}
}






















