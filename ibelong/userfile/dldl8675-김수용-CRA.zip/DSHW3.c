//  DSHW3.c
//  Created by Mainea on 2017. 4. 11..
//  Copyright © 2017년 Mainea. All rights reserved.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_data 100
typedef char BTString;
typedef int Key;
typedef struct bTreeNode   //define tree node structure
{
    Key key;
    BTString data[MAX_data];
    struct bTreeNode* left;
    struct bTreeNode* right;
} BTreeNode;





void printData(BTreeNode* bt) //printf data of nominated
{
    printf("%s", bt->data);
}

BTString GetKey(BTreeNode* bt)
{
    
    return bt->key;
}
void Setdata(BTreeNode* bt, BTString data[MAX_data]) //set data
{
    strcpy(bt->data, data);
}

void SetKey(BTreeNode* bt, Key key) //set data
{
    bt->key = key;
}


BTreeNode* GetLeftSubTree(BTreeNode* bt) //left child return
{
    return bt->left;
}

BTreeNode* GetRightSubTree(BTreeNode* bt) //right child return
{
    return bt->right;
}

void MakeLeftSubTree(BTreeNode* main, BTreeNode* sub) //make right children
{
    if(main->left != NULL)
    {
        free(main->left);
    }
    main->left = sub;
}

void MakeRightSubTree(BTreeNode* main, BTreeNode* sub) //make left childfen
{
    if(main->right != NULL)
    {
        free(main->right);
    }
    main->right = sub;
}
/* Search Tree factors */
void BSTMakeAndInit(BTreeNode** pRoot)
{
    *pRoot = NULL;
}

void ChangeLeftSubTree(BTreeNode* main, BTreeNode* sub)
{
    main->left = sub;
}
void ChangeRightSubTree(BTreeNode* main, BTreeNode* sub)
{
    main->right = sub;
}

BTreeNode* RemoveLeftSubTree(BTreeNode* bt)
{
    BTreeNode* delNode;
    
    if(bt != NULL)
    {
        delNode = bt->left;
        bt->left = NULL;
    }
    return delNode;
}


BTreeNode* RemoveRightSubTree(BTreeNode* bt)
{
    BTreeNode* delNode;
    
    if(bt != NULL)
    {
        delNode = bt -> right;
        bt->right = NULL;
    }
    return delNode;
}

void InorderTraverse(BTreeNode* bt, void ShowKD(Key key ,BTString data[MAX_data]))
{
    if(bt == NULL)
        return ;
    InorderTraverse(bt->left, ShowKD);
    ShowKD(bt->key , bt->data);
    InorderTraverse(bt->right, ShowKD);
}

void ShowKD(Key key ,BTString data[MAX_data])
{
    printf("%d %s\n",key, data);
}

void BSTShowAll(BTreeNode* bst)
{
    InorderTraverse(bst, ShowKD);
}

/* before this point : structure of tree
   after this point : construct binary search tree
 */



void BSTInsert(BTreeNode** pRoot, Key key, BTString data[MAX_data]) //searching , new node, insert
{
    BTreeNode* pNode = NULL;
    BTreeNode* cNode = *pRoot;
    BTreeNode* nNode = NULL;    //condition of initiation search tree
    
    //searching
    while(cNode != NULL) //its final lotation
    {
        if(key == GetKey(cNode))
        {
            return;
        }
        
        pNode = cNode;
        
        if(GetKey(cNode) > key)
            cNode = GetLeftSubTree(cNode);
        else
            cNode = GetRightSubTree(cNode);
    }
    nNode = MakeBTreeNode();
    Setdata(nNode , data);
    SetKey(nNode, key); //new node produce  string key
    
    
    if(pNode !=NULL)
    {
        if(key <GetKey(pNode))
            MakeLeftSubTree(pNode, nNode);
        else
            MakeRightSubTree(pNode, nNode);
    }
    else
    {
        *pRoot = nNode;
    }
}

BTreeNode* BSTsearch(BTreeNode* bst, Key key)
{
    BTreeNode* cNode = bst;
    Key ck; //current key
    
    while(cNode != NULL)
    {
        ck = GetKey(cNode);
        
        if(key == ck)
            return cNode;
        else if(key < ck)
            cNode = GetLeftSubTree(cNode);
        else
            cNode = GetRightSubTree(cNode);
    }
    return NULL;
}


/* From this point, we make function for delete*/



/* when you use printf, use for loop + search func + printf  key in order (2, choi) (3, henry)....
   make one function   restrict positive integer
   for(int i = 0 ; ;i ;i++)
   {
     BSTsearch(BTreeNode* bst, Key target)
   }
 
 */

BTreeNode* BSTRemove(BTreeNode** pRoot, Key key)
{
    BTreeNode* pVRoot = MakeBTreeNode(); //virtual root node
    BTreeNode* pNode = pVRoot; //parent
    BTreeNode* cNode = *pRoot; //cureent
    BTreeNode* dNode; //delete node
    
    ChangeRightSubTree(pVRoot, *pRoot);
    
    //search what have to delete
    
    while(cNode != NULL && GetKey(cNode) != key)
    {
        pNode = cNode;
        if(key < GetKey(cNode))
            cNode = GetLeftSubTree(cNode);
        else
            cNode = GetRightSubTree(cNode);
    }
    if(cNode == NULL) //No delete node
        return NULL;
    
    dNode = cNode;
    
    // 1st. have no child
    if(GetLeftSubTree(dNode) == NULL && GetLeftSubTree(dNode) == NULL)
    {
        if(GetLeftSubTree(pNode) == dNode)
            RemoveLeftSubTree(pNode);
        else
            RemoveRightSubTree(pNode);
    }
    
    //2nd. one child node
    else if(GetLeftSubTree(dNode) == NULL || GetRightSubTree(dNode) == NULL)
    {
        BTreeNode* dcNode;
        
        if(GetLeftSubTree(dNode) != NULL)
            dcNode = GetLeftSubTree(dNode);
        else
            dcNode = GetRightSubTree(dNode);
        
        if(GetLeftSubTree(pNode) == dNode)
            ChangeLeftSubTree(pNode, dcNode);
        else
            ChangeRightSubTree(pNode, dcNode);
    }
    
    else
    {
        BTreeNode* mNode = GetRightSubTree(dNode); //substitute node
        BTreeNode* mpNode = dNode; //parent of substitute node
      
        int delKey;
        
        while(GetLeftSubTree(mNode) != NULL)
        {
            mpNode = mNode;
            mNode = GetLeftSubTree(mNode);
        }
        
        
        delKey = GetKey(dNode);
      
        SetKey(dNode, GetKey(mNode));
        if(GetLeftSubTree(mpNode) == mNode)
            ChangeLeftSubTree(mpNode, GetRightSubTree(mNode));
        else
            ChangeRightSubTree(mpNode, GetRightSubTree(mNode));
        
        dNode = mNode;
       
        SetKey(dNode, delKey);
    }
    
    if(GetRightSubTree(pVRoot) != *pRoot)
        *pRoot = GetRightSubTree(pVRoot);
    
    free(pVRoot);
    return dNode;
}






int main()
{
    
    
    char OR;
    int KN;
    BTreeNode* bstRoot;
    BTreeNode* sNode;
    
    BSTMakeAndInit(&bstRoot);
    
    
    
    
    do
    {
         OR = '\0';
         KN = 0;
         char KD[MAX_data] = "\0";
         char Input[MAX_data + 2] = "\0";
         char* result = NULL;
    
        fgets( Input, sizeof(Input), stdin);
        result = strtok(Input , " ");
    
    while(result != NULL)
    {
        
        if(result == &Input[0])
        {
            OR = *result;
        }
        else if(result == &Input[2])
        {
            KN = atoi(result);
        }else
        {
            strcpy(KD, result);
        }
        result = strtok(NULL, " ");
    }
    
    
    
    switch(OR)
    {
        case 'a':
            BSTInsert(&bstRoot, KN, KD);
            break;
            
        case 'd':
            sNode = BSTRemove(&bstRoot, KN);
            free(sNode);
            break;
        case 'p':
            BSTShowAll(bstRoot);
            break;
        
    }
    }while(OR != 'q');
    
    }
    
    
    
    
    
















