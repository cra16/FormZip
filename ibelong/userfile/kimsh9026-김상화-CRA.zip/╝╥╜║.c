/***

�� ���α׷��� ������� ���ǿ� ���� �����̴� Bar�� �����ϰ�,
Bouncing �ϴ� ball�� �̿��� ȭ�鿡 ǥ�õ� �������� �����ϴ� �����̴�.

"J" �� "L" Ű�� Bar�� ��ġ�� �����Ѵ�

21600079 ���ȭ

**/

#include <stdio.h>
#include <conio.h>
#include <windows.h>

#define ABS(X) ((X) >= 0 ? (X) : -(X))
#define COLUMN 80
#define ROW 23

const int LeftBound = 1;
const int RightBound = 80;
const int TopBound = 1;
const int BottomBound = 24;
const int FighterWidth = 5;

char screen[24][81];

// declaration of major functions
void MapCanvas(char map[24][81]);
char BouncingBall(int sx, int sy, int dx, int dy, char map[24][81]);
void clrscr(void);
void gotoxy(int x, int y);


// helper functions
void MarkXY(int x, int y, int mode, char map[24][81]);
void MarkBoundary(char map[24][81]);
void DisplayXY(int x, int y, char map[24][81]);
void DisplayMap(char map[24][81]);

// Enable Cursor
void EnableCursor(int enable)
{
	CONSOLE_CURSOR_INFO cursorInfo = { 0, };
	cursorInfo.dwSize = 1;
	cursorInfo.bVisible = enable;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
}

int main()
{
	EnableCursor(0);

	char decide = 0;

	// Create Map
	MapCanvas(screen);

	// BoucningBall
	decide = BouncingBall(20, 10, 2, 1, screen);


	clrscr();
	gotoxy(1, 1);

	if (decide == 'w')
		printf("���ӿ��� �¸��߽��ϴ�\n");
	else
		printf("���ӿ��� �й��߽��ϴ�\n");


	system("PAUSE");

	return 0;
}


void MapCanvas(char map[24][81])
{

	int x = 0, y = 0;
	// initialize map array
	for (y = TopBound; y < BottomBound; y++) {
		for (x = LeftBound; x < RightBound; x++)
			map[y][x] = 0;
	}

	// Set Boundary
	MarkBoundary(map);

	clrscr();
	gotoxy(1, 1);
}

void MarkBoundary(char map[24][81])
{
	int x = 0, y = 0;

	// ����
	for (y = TopBound; y <= BottomBound; y++) {
		map[y][LeftBound] = 1;
		map[y][RightBound] = 1;
	}

	// �¿�
	for (x = LeftBound; x <= RightBound; x++) {
		map[TopBound][x] = 1;

	}


	// ����
	for (x = 2; x<78; x++) {
		for (y = 2; y<5; y++) {
			gotoxy(x, y);
			map[y][x] = 2;
		}
	}


}

void DisplayXY(int x, int y, char map[24][81])
{
	gotoxy(x, y);
	switch (map[y][x]) {
	case 0:
		putchar(' ');
		break;
	case 1:
		putchar(' ');
		break;
	case 2:
		putchar('#');
		break;

	}
}

void DisplayMap(char map[24][81])
{
	int x, y;

	for (y = TopBound; y <= BottomBound; y++) {
		for (x = LeftBound; x <= RightBound; x++) {
			DisplayXY(x, y, map);
		}
	}
}

char BouncingBall(int sx, int sy, int dx, int dy, char map[24][81])
{
	float x = sx, y = sy;
	float oldx = 0, oldy = 0;
	float fdx = 0., fdy = 0.;
	int max = dx;
	int LifePoint = 5;
	int Score = 0;

	char key = 0;
	int n = 0;

	char bar[20] = "=============";
	char eraser[20] = "             ";
	int len = strlen(bar);
	int bx = 40 - len / 2, by = 23;
	int bprevX = bx, bprevY = by;            // prevY is not necessary in this program
	char bc = 0;

	int bdir = 0;
	int counter_bar = 0;

	if (dx != 0 && ABS(dx) >= ABS(dy)) {
		fdx = (dx > 0 ? 1. : -1.);
		fdy = dy / (float)ABS(dx);
	}
	else if (dy != 0) {
		fdx = dx / (float)ABS(dy);
		fdy = (dy > 0 ? 1. : -1.);
		max = dy;
	}
	else {
		fdx = dx;
		fdy = dy;
	}

	if (max <= 0)      // for safety
		max = 1;

	DisplayMap(map);



	x = oldx = sx;
	y = oldy = sy;



	do {
		gotoxy(bprevX, bprevY);
		printf("%s", eraser);

		// �ʱ�ȭ bar
		for (counter_bar = 0; counter_bar <= 7; counter_bar++) {
			map[bprevY][bprevX + counter_bar] = 0;
		}

		for (counter_bar = -1; counter_bar <= 8; counter_bar++) {
			map[bprevY + 1][bprevX + counter_bar] = 0;
		}

		gotoxy(bx, by);
		printf("%s", bar);


		//bouncing bar
		for (counter_bar = 0; counter_bar <= 7; counter_bar++) {
			map[by][bx + counter_bar] = 1;
		}

		for (counter_bar = -1; counter_bar <= 8; counter_bar++) {
			map[by + 1][bx + counter_bar] = 1;
		}

		bprevX = bx;
		bprevY = by;


		// Moving Bar
		if (_kbhit()) {
			bc = _getch();
			switch (bc) {
			case 'j':
				bdir = -1;
				break;
			case 'l':
				bdir = 1;
				break;
			default:
				bdir = 0;
				break;
			}
		}

		bx += bdir;
		if (bx < 1)
			bx = 1;
		if (bx + len - 1 > 80)
			bx = 80 - len + 1;

		if (n % max == 0) {

			//LifePoint
			if ((int)y == 25) {

				x = sx;
				y = sy;
				LifePoint = LifePoint - 1;

			}

			// display ball         
			gotoxy((int)x, (int)y);
			putchar('*');

			// erase previous ball
			if (x != oldx || y != oldy) {
				gotoxy((int)oldx, (int)oldy);
				putchar(' ');
			}
		}

		Sleep(100 / max);

		// save current position
		if (n % max == 0) {
			oldx = x;
			oldy = y;
		}

		x += fdx;
		y += fdy;

		if (map[(int)y][(int)x] == 1) {
			if (map[(int)oldy][(int)x] == 1 && map[(int)y][(int)oldx] == 0) { // vertical wall
				fdx = -fdx;
				x = oldx + fdx;
				if (map[(int)y][(int)x] == 1) {   // bounced again
					if (map[(int)oldy][(int)x] == 0) {
						x = oldx;
						y = oldy;
						fdy = -fdy;
					}
					else {
						fdx = -fdx;
						x = oldx;
					}

				}
			}
			else if (map[(int)oldy][(int)x] == 0 && map[(int)y][(int)oldx] == 1) { // horizontal wall

				fdy = -fdy;
				y = oldy + fdy;
				if (map[(int)y][(int)x] == 1) {   // bounced again
					if (map[(int)y][(int)oldx] == 0) {
						x = oldx;
						y = oldy;
						fdx = -fdx;
					}
					else {
						fdy = -fdy;
						y = oldy;
					}
				}
			}
			else {         // corner
				fdx = -fdx;
				fdy = -fdy;
				x = oldx + fdx;
				y = oldy + fdy;
				if (map[(int)y][(int)x] == 1) {   // bounced again
					x = oldx;
					y = oldy;
				}
			}
		}
		if (map[(int)y][(int)x] == 2) {
			if (map[(int)oldy][(int)x] == 2 && map[(int)y][(int)oldx] == 0) { // vertical wall
				fdx = -fdx;
				gotoxy((int)x, (int)y);
				putchar(' ');
				map[(int)y][(int)x] = 0;
				x = oldx + fdx;
				if (map[(int)y][(int)x] == 2) {   // bounced again
					if (map[(int)oldy][(int)x] == 0) {
						x = oldx;
						y = oldy;
						fdy = -fdy;
					}
					else {
						fdx = -fdx;
						x = oldx;
					}

				}
			}
			else if (map[(int)oldy][(int)x] == 0 && map[(int)y][(int)oldx] == 2) { // horizontal wall

				fdy = -fdy;
				gotoxy((int)x, (int)y);
				putchar(' ');
				map[(int)y][(int)x] = 0;
				y = oldy + fdy;
				if (map[(int)y][(int)x] == 2) {   // bounced again
					if (map[(int)y][(int)oldx] == 0) {
						x = oldx;
						y = oldy;
						fdx = -fdx;
					}
					else {
						fdy = -fdy;
						y = oldy;
					}
				}
			}
			else {         // corner
				fdx = -fdx;
				fdy = -fdy;
				gotoxy((int)x, (int)y);
				putchar(' ');
				map[(int)y][(int)x] = 0;
				x = oldx + fdx;
				y = oldy + fdy;
				if (map[(int)y][(int)x] == 2) {   // bounced again
					x = oldx;
					y = oldy;
				}


			}
			//Scroe
			Score = Score + 10;
		}

		n++;

		gotoxy(1, 1);
		printf("  �������� ����  ");
		gotoxy(1, BottomBound + 1);
		printf("LifePoint = %d    Score = %d    //21600079 ���ȭ", LifePoint, Score);

		if (LifePoint == 0)
			return 'l';
		if (Score >= 300)
			return 'w';



	} while (1);
}

void clrscr(void)      // clear the screen
{
	COORD Cur = { 0, 0 };
	unsigned long dwLen = 0;

	gotoxy(1, 1);

	FillConsoleOutputCharacter(GetStdHandle(STD_OUTPUT_HANDLE), ' ', 80 * 25, Cur, &dwLen);
}

void gotoxy(int x, int y)   // move cursor to (x, y)
{
	COORD Pos = { x - 1, y - 1 };

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
