package javacamp;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class peopleInfor extends JDialog implements ActionListener {
	
	JPanel pw = new JPanel(new GridLayout(6,1)); //����
	JPanel pc = new JPanel(new GridLayout(6,4)); //�߾�
	JPanel ps = new JPanel();

	JLabel label_Name = new JLabel("�̸�(Name) :");
	JLabel label_Number = new JLabel("��ȣ(Number) :");
	JLabel label_Email = new JLabel("����(Email) :");
	JLabel label_Birth = new JLabel("����(Birth) :");
	JLabel label_Gender = new JLabel("����(Gender) :");
	JLabel label_Relation = new JLabel("����(Relation) :");
	
	JTextField name = new JTextField(16); // �̸��� ���� �ؽ�Ʈ�ʵ带 �������ִ� ����
	JPanel namep = new JPanel(new FlowLayout(FlowLayout.LEFT));//(new FlowLayout(FlowLayout.LEFT));
	JTextField number1 = new JTextField(3);
	JTextField number2 = new JTextField(4);
	JTextField number3 = new JTextField(4);// 3���� ���� ����ϱ� ���� �ʿ�.
	JPanel numberp = new JPanel(new FlowLayout(FlowLayout.LEFT)); // �̰� ������ �����ϴ°� ;
	JTextField email1 = new JTextField(7);
	JTextField email2 = new JTextField(6);
	JPanel emailp = new JPanel(new FlowLayout(FlowLayout.LEFT));
	JTextField year = new JTextField(5);
	JTextField month = new JTextField(3);
	JTextField date = new JTextField(3);
	JPanel birthp = new JPanel(new FlowLayout(FlowLayout.LEFT));
	JRadioButton man = new JRadioButton("man", true);
	JRadioButton women = new JRadioButton("women", true); //�� ��
	JPanel genderp = new JPanel(new FlowLayout(FlowLayout.LEFT));	
	String[] relat = {"other", "familly", "friend", "workmate", "acquaintance"};
	JComboBox relations = new JComboBox(relat); // JPanel relation();
	JPanel relationp = new JPanel(new FlowLayout(FlowLayout.LEFT));
	
	//JPanel button = new JPanel();
	JButton save;
	JButton cancel = new JButton("Cancel");
	
	Menubar me;
	
	// �����ͺ��̽� �ҷ����°� 
	db_Contact database = new db_Contact();
	//
	
	public changeInfor getData(){
		
		// �Է��� ������ ��Ʈ������ �ٲ㼭 ����
		changeInfor dto = new changeInfor();
		String Name = name.getText();
		String Number1 = number1.getText();
		String Number2 = number2.getText();
		String Number3 = number3.getText();
		String Number = Number1+"-"+Number2+"-"+Number3;
		String Email1 = email1.getText();
		String Email2 = email2.getText();
		String Email = Email1+"@"+Email2;
		String Year = year.getText();
		String Month = month.getText();
		String Date = date.getText();
		String Birth = Year+"/"+Month+"/"+Date;
		String Gender = "";
		if(man.isSelected()){
			Gender = "M";
		}
		else if(women.isSelected()){
			Gender = "W";
		}
		String Relation = (String)relations.getSelectedItem();
		
		dto.setName(Name);
		dto.setNumber(Number);
		dto.setEmail(Email);
		dto.setBirth(Birth);
		dto.setGender(Gender);
		dto.setRelation(Relation);
		
		return dto;
	}
	
	public peopleInfor(Menubar me, String index){
		super(me, "Information");
		this.me = me;
		
		if(index.equals("Insert")){
			save = new JButton(index);
		}
		else { 
			//text�ڽ��� ���� �ֱ�
			int row = me.JTfix.getSelectedRow(); // ���õ� ��
			name.setText(me.JTfix.getValueAt(row, 0).toString());

			String numberss = me.JTfix.getValueAt(row, 1).toString();
			String number1ss = numberss.substring(0, numberss.indexOf('-'));
			String number2ss = numberss.substring(numberss.indexOf('-')+1, numberss.lastIndexOf('-'));
			String number3ss = numberss.substring(numberss.lastIndexOf('-')+1);
			number1.setText(number1ss); // ��ȣ ���õ� ���� 1��° ��
			number2.setText(number2ss);
			number3.setText(number3ss);

			String emailss = me.JTfix.getValueAt(row, 2).toString();
			String email1ss = emailss.substring(0, emailss.indexOf('@'));
			String email2ss = emailss.substring(emailss.indexOf('@')+1);
			email1.setText(email1ss);
			email2.setText(email2ss);
			
			String birthss = me.JTfix.getValueAt(row, 3).toString();
			String yearss = birthss.substring(0, birthss.indexOf('/'));
			String monthss = birthss.substring(birthss.indexOf('/')+1, birthss.lastIndexOf('/'));
			String datess = birthss.substring(birthss.lastIndexOf('/')+1);
			year.setText(yearss);
			month.setText(monthss);
			date.setText(datess);
			
			if((me.JTfix.getValueAt(row, 4)).equals("M")) {
				man.setSelected(true);
			}
			else if((me.JTfix.getValueAt(row, 4)).equals("W")) {
				man.setSelected(false);
			}
			
			relations.setSelectedItem(me.JTfix.getValueAt(row, 5));
			
			if(index.equals("NameEdit")) {
				number1.setEditable(false);
				number2.setEditable(false);
				number3.setEditable(false);
				email1.setEditable(false);
				email2.setEditable(false);
				year.setEditable(false);
				month.setEditable(false);
				date.setEditable(false);
				man.setEnabled(false);
				women.setEnabled(false);
				relations.setEditable(false);
				save = new JButton("NameEdit");
			}
			else if(index.equals("OtherEdit")){
				name.setEditable(false);
				save = new JButton("OtherEdit");
			}
		}
		
		// ����â�� Label�߰� �κ�
		pw.add(label_Name);//�̸� �� �߰�
		pw.add(label_Number);
		pw.add(label_Email);
		pw.add(label_Birth);
		pw.add(label_Gender);
		pw.add(label_Relation);

		//TextField �߰�
		//name = new JTextField(16);
		namep.add(name);
		pc.add(namep);
			
		numberp.add(number1);
		numberp.add(new JLabel(" - "));
		numberp.add(number2);
		numberp.add(new JLabel(" - "));
		numberp.add(number3);
		pc.add(numberp);
		
		emailp.add(email1);
		emailp.add(new JLabel("@"));
		emailp.add(email2);
		pc.add(emailp);
		
		birthp.add(year);
		birthp.add(new JLabel(" / "));
		birthp.add(month);
		birthp.add(new JLabel(" / "));
		birthp.add(date);
		pc.add(birthp);
		
		ButtonGroup group = new ButtonGroup(); // ��ư�� �׷�ȭ
		group.add(man);
		group.add(women);
		genderp.add(man);
		genderp.add(women);
		pc.add(genderp);
		
		relationp.add(relations);
		pc.add(relationp);
		
		//�Ʒ� ��ư
		ps.add(save); // ����
		ps.add(cancel); // ���
		
		add(pw,"West");
		add(pc,"Center");
		add(ps,"South");
		//�̺�Ʈ ����
		save.addActionListener(this);//�����̺�Ʈ
		cancel.addActionListener(this);//����̺�Ʈ
	}//inforâ ��
	
	//�׼� ��� �κ�
	@Override
	public void actionPerformed(ActionEvent e){
		String btnLabel = e.getActionCommand(); // ���࿡ ���� Label �������� ��
		
		if(btnLabel.equals("Insert")){
			if(database.Insert(this) > 0){//���� �����̷�
				messageBox(this, "Saved");
				dispose(); //â�ݱ�
				
				database.Selectall(me.defaulttable); // ��� ��� �����ͼ� �ø���
				
				if(me.defaulttable.getRowCount()>0)
					me.JTfix.setRowSelectionInterval(0,0);
			}
			else messageBox(this, "Failed");
		}
		else if(btnLabel.equals("NameEdit")){ 
			
			if(database.NameUpdate(this) > 0){
				messageBox(this, "Saved");
				dispose();
				
				database.Selectall(me.defaulttable);

				if(me.defaulttable.getRowCount() > 0)
					me.JTfix.setRowSelectionInterval(0, 0);
			}
			else messageBox(this, "Failed");
		}
		else if(btnLabel.equals("OtherEdit")){
			
			if(database.OtherUpdate(this) > 0){
				messageBox(this, "Saved");
				dispose();
				
				database.Selectall(me.defaulttable);

				if(me.defaulttable.getRowCount() > 0)
					me.JTfix.setRowSelectionInterval(0, 0);
			}
			else messageBox(this, "Failed");
		}
		else if(btnLabel.equals("Cancel")){
			dispose();
		}
	}//action ��
	//�޼����ڽ�
	public static void messageBox(Object obj, String message){
		JOptionPane.showMessageDialog((Component)obj, message);
	}
}
