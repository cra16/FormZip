package javacamp;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Menubar extends JFrame implements ActionListener {
	JMenu menu = new JMenu("Menu");
	JMenuItem insert = new JMenuItem("Insert");
	JMenuItem nameupdate = new JMenuItem("NameEdit");
	JMenuItem otherupdate = new JMenuItem("OtherEdit");
	JMenuItem delete = new JMenuItem("Delete");
	JMenuItem close = new JMenuItem("Close");
	JMenuBar menubar = new JMenuBar();
	
	String[] name = {"Name","Number","Email","Birth","Gender","Relation"};
	
	DefaultTableModel defaulttable = new DefaultTableModel(name,0); // 목록별로 들어간 걸 만들고
	JTable JTfix = new JTable(defaulttable);// 고정된 테이블로 저장
	JScrollPane printTable = new JScrollPane(JTfix); // 목록을 표시할 
	
	/*
	 * South 영역에 추가할 Component 들
	 */
	JPanel searchNsort = new JPanel();
	String[] comboSearch = {"SelectAll", "Name", "Number", "Email", "Birth"};//성별이랑 관계는 정렬할때만 쓰면 됨.
	
	JComboBox combobox = new JComboBox(comboSearch);
	JTextField searchField = new JTextField(15);
	JButton search = new JButton("Search");
	JButton sort = new JButton("Sort");//정렬
	
	db_Contact database = new db_Contact();
	
	/**
	 * 화면구성 이벤트
	 */
	public Menubar(){
		super("지히 팬 목록");
		//메뉴종류들을 메뉴에 추가
		menu.add(insert);
		menu.add(nameupdate);
		menu.add(otherupdate);
		menu.add(delete);
		menu.add(close);
		
		//메뉴바에 메뉴를 추가
		menubar.add(menu);
		
		//윈도우에 메뉴바 세팅
		setJMenuBar(menubar);
		
		//추가, 검색영역
		
		searchNsort.add(combobox);
		searchNsort.add(searchField);
		searchNsort.add(search);
		searchNsort.add(sort);
		
		//각각 화면에 표시
		add(printTable, "Center");
		add(searchNsort, "South");
		//크기지정
		setSize(500,400);
		setVisible(true);
		
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//이벤트 등록
		insert.addActionListener(this);
		nameupdate.addActionListener(this);
		otherupdate.addActionListener(this);
		delete.addActionListener(this);
		close.addActionListener(this);
		
		search.addActionListener(this);
		sort.addActionListener(this);
		
		//모든 기록을 검사해서 셋팅하기
		database.Selectall(defaulttable);
		
		//첫번째행 선택.
		if(defaulttable.getRowCount()>0){
			JTfix.setRowSelectionInterval(0, 0); // 고정창을 0행 0열에 저장
		}
	}//생성자 종료
	
	public static void main(String[] args){
		new Menubar();
	}
	
	//추가 수정 삭제 검색 담당 메소드
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == insert){
			new peopleInfor(this, "Insert");
		}
		else if(e.getSource() == nameupdate){//수정 메뉴
			new peopleInfor(this, "NameEdit");
		}
		else if(e.getSource() == otherupdate){//수정 메뉴
			new peopleInfor(this, "OtherEdit");
		}
		else if(e.getSource() == delete){//삭제메뉴
			//현재 선택된 행과 열의 값을 얻어와서 삭제할것이므로 얻와야야함
			int row = JTfix.getSelectedRow();
		//	System.out.println("선택행 : "+row);
			Object obj = JTfix.getValueAt(row, 0);
		//	System.out.println("값 : "+obj);	
			if(database.Delete(obj.toString())>0){
				peopleInfor.messageBox(this, "delete");
				
				database.Selectall(defaulttable);
				if(defaulttable.getRowCount()>0)
					JTfix.setRowSelectionInterval(0, 0);
			}
			else {
				peopleInfor.messageBox(this, "Canceled");
			}
		}
		else if(e.getSource() == close){
			System.exit(0);
		}
		else if(e.getSource() == search){ //검색하기
		//콤보박스에서 선택된 값을 가져오기
			String fieldname = combobox.getSelectedItem().toString();
			System.out.println("종류" + fieldname);
			
			if(fieldname.trim().equals("SelectAll")){//전체검색
				database.Selectall(defaulttable);
				if(defaulttable.getRowCount()>0)
					JTfix.setRowSelectionInterval(0, 0);
			}
			else{
				if(searchField.getText().trim().equals("")){
					peopleInfor.messageBox(this, "cannot be found");
					searchField.requestFocus();
				}
				else{
					database.Search(defaulttable, fieldname, searchField.getText());
					if(defaulttable.getRowCount()>0)
						JTfix.setRowSelectionInterval(0, 0);
				}
			}
		}
		else if(e.getSource() == sort){//정렬 메뉴 아이템
			String fieldname = combobox.getSelectedItem().toString();
			if(fieldname.trim().equals("SelectAll")){
				peopleInfor.messageBox(this, "select sort type");
			}
			else{
				database.Selectall(defaulttable);
				database.sort(defaulttable, fieldname);
				if(defaulttable.getRowCount()>0)
					JTfix.setRowSelectionInterval(0, 0);
			}
		}
		
	}
}
