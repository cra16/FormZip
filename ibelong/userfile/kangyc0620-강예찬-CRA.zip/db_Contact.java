package javacamp;
import java.sql.*;

import javax.swing.table.DefaultTableModel;

public class db_Contact {

	// 변수 설정
	Connection conn ;
	Statement stat ;
	PreparedStatement ps;
	ResultSet rs;

	public db_Contact(){
		try{
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbContact", "root", "1406") ;
			stat = conn.createStatement() ;
			//stat.executeUpdate("CREATE TABLE contact(name, number , email , birth , gender , relation);"); 
			System.out.println("연결성공");
		}catch (ClassNotFoundException e) {
			System.out.println(e + "=> 로드 fail");
		}catch (SQLException e) {
			System.out.println(e + "=> 연결 fail");
		}
	}

	public void db_close(){
		try {
			if (rs != null) rs.close();
			if (stat != null) stat.close();
			if (ps != null) ps.close();

		} catch (Exception e) {
			System.out.println(e + "=> db_close fail");
		}
	}
	
	 /**
     * 저장 하는 기능 메소드
	 **/
	public int Insert(peopleInfor infor){
		int result = 0;
		changeInfor user = infor.getData();
		
		try{
			ps = conn.prepareStatement("INSERT INTO contact values(?,?,?,?,?,?)");
			ps.setString(1, user.getName());
			ps.setString(2, user.getNumber());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getBirth());
			ps.setString(5, user.getGender());
			ps.setString(6, user.getRelation());

			result = ps.executeUpdate(); // 실행 --> 저장		
		}
		catch(SQLException e){
			System.out.println(user.toString());
			System.out.println(e + "+> userListInsert fail");
		}
		finally{
			db_close();
		}
		return result;
	}
	
	// DB내용을 조회하는 것
	public void Selectall(DefaultTableModel t_model){
		try{
			stat = conn.createStatement();
			rs = stat.executeQuery("SELECT * FROM contact ORDER BY name");

			//DefaultTableModel에 있는 기존 데이터 지우기
			for(int i = 0; i < t_model.getRowCount();){
				t_model.removeRow(0);
			}
			while(rs.next()) {
				Object data[] = { rs.getString(1), rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getString(5), rs.getString(6) };
				
				t_model.addRow(data); // DefaultTableModel에 레코드를 추가
			}
		}
		catch(SQLException e) {
			System.out.println(e +"=> userSelectAll fail");
		}
		finally{
			db_close();
		}
	}

	//이름에 해당하는 레코드 삭제
	public int Delete(String name){
		int result = 0;
		try{
			ps = conn.prepareStatement("DELETE FROM contact WHERE name = ? LIMIT 1");
			ps.setString(1, name.trim());
			result = ps.executeUpdate();
		}
		catch (SQLException e) {
			System.out.println(e + "=> userDelete fail");
		}
		finally {
			db_close();
		}
		return result;
	}
	
	//이름에 해당하는 기록 수정하기.
	public int NameUpdate(peopleInfor infor){
		int result=0;
		changeInfor user = infor.getData();
		String sql = "UPDATE contact SET name = ? WHERE number = ? LIMIT 1";
		
		try{
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getNumber());
			
			result = ps.executeUpdate();
		}
		catch(SQLException e){
			System.out.println(e + "=> userUpdate fail");
		}
		finally{
			db_close();
		}
		return result;
	}// 수정
	public int OtherUpdate(peopleInfor infor){
		int result=0;
		changeInfor user = infor.getData();
		String sql = "UPDATE contact SET number = ? , email = ? , birth = ? , gender = ? , relation = ? WHERE name=? LIMIT 1";
		
		try{
			ps = conn.prepareStatement(sql);
			// ? 에 순서대로 값 넣기
			ps.setString(1, user.getNumber());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getBirth());
			ps.setString(4, user.getGender());
			ps.setString(5, user.getRelation());
			ps.setString(6, user.getName());
			
			result = ps.executeUpdate();
		}
		catch(SQLException e){
			System.out.println(e + "=> userUpdate fail");
		}
		finally{
			db_close();
		}
		return result;
	}// 수정
	//검색하기
	public void Search(DefaultTableModel defaulttable, String fieldName, String word){
		String sql = "SELECT * FROM contact WHERE " + fieldName.trim() + " LIKE '%" + word.trim() + "%'";
		
		try{
			stat = conn.createStatement();;
			rs = stat.executeQuery(sql);
			
			//DefaultTableModel에 있는 기존 데이터 지우기
			for(int i = 0; i< defaulttable.getRowCount();) {
				defaulttable.removeRow(0);
			}
			while(rs.next()){
				Object data[] = { rs.getString(1), rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getString(5), rs.getString(6) };
				
				defaulttable.addRow(data);
				}
		}
		catch(SQLException e) {
			System.out.println(e + "=> getUserSearch fail");
		}
		finally {
			db_close();
		}
	}
	public void sort(DefaultTableModel defaulttable, String fieldName) {
		String sql = "SELECT * FROM contact ORDER BY " + fieldName.trim();
		try {
			stat = conn.createStatement();
			rs = stat.executeQuery(sql);
			
			for(int i = 0; i < defaulttable.getRowCount();){
				defaulttable.removeRow(0);
			}
			while(rs.next()) {
				System.out.println(rs.getString(1));
				Object data[] = { rs.getString(1), rs.getString(2), rs.getString(3),
						rs.getString(4), rs.getString(5), rs.getString(6) };
				
				defaulttable.addRow(data); // DefaultTableModel에 레코드를 추가
			}
		}
		catch(SQLException e) {
			System.out.println(e + "=> sort fail");
		}
		finally {
			db_close();
		}
	}
	
}
