package javacamp;

public class changeInfor {
	private String name;
	private String number;
	private String email;
	private String birth;
	private String gender;
	private String relation;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name.trim().toLowerCase();
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number.trim();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email.trim();
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth.trim();
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender.trim();
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation.trim();
	}
	
	@Override
	public String toString() {
		return "peopleInfor [name=" + name + ", number=" + number + ", email=" + email + ", birth=" + birth
				+ ", gender=" + gender + ", relation=" + relation + "]";
	}
	
	
}
