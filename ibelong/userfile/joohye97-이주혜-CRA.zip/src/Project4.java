
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.Statement;

class State
{
	public static Statement s;
	public static ResultSet rs;
	public static ResultSetMetaData rsmd;
	
	 State()
	 { 
		 Connection con = null; 
		 try 
		 { 
			 Class.forName("com.mysql.jdbc.Driver").newInstance(); 
			 con = DriverManager.getConnection("jdbc:mysql://127.0.0.1", "root", "qewr1324"); 
		 
			 s=(Statement)con.createStatement();
			 rs=s.executeQuery("use CSEE");
			 
			 if (con.isClosed() == false) 
			 System.out.println("Successfully connected to MySQL server."); 
		 } 
		 catch(Exception e) 
		 {
			 System.err.println("Exception: " + e.getMessage());
		 }
	/*	 try
		 { 
			 if (con != null) 
				 con.close(); 
			 } 
		 catch(SQLException e) {} */
	 }
}

public class Project4  extends JFrame implements ActionListener
{
	public CardLayout cards=new CardLayout();

	public JPanel jp=new JPanel();
	JPanel login=new JPanel();
	
	public static String ids;
	public static String pws;
	public static String idj;
	
	public static JTextField idl=new JTextField(30);
	public static JPasswordField pwl=new JPasswordField(30);
	
	JTextField idla=new JTextField(30);
	JPasswordField pwla=new JPasswordField(30);
	
	int count=0;
	
	/***���� textField***/
	JTextField tNameC=new JTextField(30);
	JTextField sNumC=new JTextField(30);
	JTextField tIdC=new JTextField(30);
	JPasswordField tPwC=new JPasswordField(30);
	JTextField major_1C=new JTextField(30);
	JTextField t2majorC=new JTextField(30);
	
	/***���� textField***/
	JTextField tName=new JTextField(30);
	JTextField sNum=new JTextField(30);
	JTextField tId=new JTextField(30);
	JTextField major_1=new JTextField(30);
	JTextField t2major=new JTextField(30);
	JTextField tPw=new JTextField(30);
	
	JPanel cor=new JPanel();//����
	
	public Project4()
	{
		setSize(800,1000);
		jp.setLayout(cards);
		jp.setBounds(0, 0, 800, 1000);
		//setResizable(false);
		setBackground(Color.white);
		State st = new State();
		
		login.setBackground(Color.white);
		login.setBounds(0, 0, 800, 1000);
		login.setLayout(null);
		
		JLabel main=new JLabel("CSEE");
		main.setFont(new Font("Serif", Font.BOLD, 100));
		main.setBounds(0,0,800,200);
		login.add(main);
		
		
		JLabel id=new JLabel("ID");
		JLabel pw=new JLabel("PW");
		
		id.setFont(new Font("Serif", Font.BOLD, 30));
		pw.setFont(new Font("Serif", Font.BOLD, 30));
		
		
		
		idl.setBounds(300,300,200,30);
		pwl.setBounds(300,350,200,30);
		
		login.add(idl);
		login.add(pwl);
		
		id.setBounds(250,260,150,100);
		pw.setBounds(250,310,150,100);
		
		login.add(id);
		login.add(pw);
		
		JButton log=new JButton("Login");
		log.setFont(new Font("Serif", Font.BOLD, 30));
		log.setBackground(Color.pink);
		log.setBounds(250, 450, 250,50);
		log.addActionListener(this);
		login.add(log);
		
		JButton jo=new JButton("Join");
		jo.setFont(new Font("Serif", Font.BOLD, 30));
		jo.setBackground(Color.pink);
		jo.addActionListener(this);
		jo.setBounds(250, 550, 250,50);
		login.add(jo);
		
		JButton adm=new JButton("Admin");
		adm.setFont(new Font("Serif", Font.BOLD, 30));
		adm.setBackground(Color.white);
		adm.setBounds(550, 890, 200,50);
		adm.addActionListener(this);
		login.add(adm);
		
		jp.add("one",login);/*��������� �α��� ȭ��*/
		/***********�α��� �� ���� �� Ż��*****************/
		
		
		cor.setBounds(0,0,800,1000);
		cor.setLayout(null);
		cor.setBackground(Color.white);
		
		JLabel corr=new JLabel("My Page");
		corr.setBounds(0,0,800,200);
		corr.setFont(new Font("Serif", Font.BOLD, 90));
		cor.add(corr);
		
		
		JLabel nameC=new JLabel("Name");
		nameC.setBounds(215,150,200,100);
		nameC.setFont(new Font("Serif", Font.BOLD, 30));
		cor.add(nameC);
		
		
		tNameC.setBounds(330,190,200,30);
		cor.add(tNameC);
		
		JLabel stNumC=new JLabel("St_Num");
		stNumC.setFont(new Font("Serif", Font.BOLD, 30));
		stNumC.setBounds(200,220,200,100);
		cor.add(stNumC);
		
		
		sNumC.setBounds(330,260,200,30);
		tNameC.setEditable(false);
		sNumC.setEditable(false);
		tIdC.setEditable(false);
		cor.add(sNumC);
		
		JLabel IDC=new JLabel("ID");
		IDC.setFont(new Font("Serif", Font.BOLD, 30));
		IDC.setBounds(230,290,200,100);
		cor.add(IDC);
		
		
		tIdC.setBounds(330,330,200,30);
		cor.add(tIdC);
		
		JLabel PwC=new JLabel("PW");
		PwC.setFont(new Font("Serif", Font.BOLD, 30));
		PwC.setBounds(230,360,200,100);
		cor.add(PwC);
		
		
		tPwC.setBounds(330,400,200,30);
		cor.add(tPwC);
		
		JLabel major1C=new JLabel("1st Major");
		major1C.setFont(new Font("Serif", Font.BOLD, 30));
		major1C.setBounds(185,440,200,100);
		cor.add(major1C);
		
		
		major_1C.setBounds(330,470,200,30);
		cor.add(major_1C);
		
		JLabel major2C=new JLabel("2nd Major");
		major2C.setFont(new Font("Serif", Font.BOLD, 30));
		major2C.setBounds(180,520,200,100);
		cor.add(major2C);
		
		
		t2majorC.setBounds(330,550,200,30);
		cor.add(t2majorC);
		
		JButton correction=new JButton("Correct");
		correction.setBackground(Color.pink);
		correction.setFont(new Font("Serif", Font.BOLD, 30));
	//	join.add();
		correction.addActionListener(this);
		correction.setBounds(300,650,200,50);
		cor.add(correction);
		
		JButton backC=new JButton("Logout");
		backC.setBackground(Color.pink);
		backC.setFont(new Font("Serif", Font.BOLD, 20));
		cor.add(backC);
		backC.addActionListener(this);
		backC.setBounds(0,900,100,50);
		
		JButton withdrawal=new JButton("Withdrawal");
		withdrawal.setBackground(Color.pink);
		withdrawal.setFont(new Font("Serif", Font.BOLD, 25));
		cor.add(withdrawal);
		withdrawal.addActionListener(this);
		withdrawal.setBounds(600,800,160,80);
		
		jp.add("three",cor);
		
		
		
		/*************ȸ������ ������*************/
		JPanel join=new JPanel();
		join.setBackground(Color.white);
		join.setBounds(0, 0, 800, 1000);
		join.setLayout(null);
		

		
		JLabel main2=new JLabel("Join");
		main2.setBounds(0,0,800,200);
		main2.setFont(new Font("Serif", Font.BOLD, 100));
		join.add(main2);
		
		JLabel name=new JLabel("Name");
		name.setBounds(215,150,200,100);
		name.setFont(new Font("Serif", Font.BOLD, 30));
		join.add(name);
		
		
		tName.setBounds(330,190,200,30);
		join.add(tName);
		
		JLabel stNum=new JLabel("St_Num");
		stNum.setFont(new Font("Serif", Font.BOLD, 30));
		join.add(name);
		stNum.setBounds(200,220,200,100);
		join.add(stNum);
		
		
		sNum.setBounds(330,260,200,30);
		join.add(sNum);
		
		JLabel ID=new JLabel("ID");
		ID.setFont(new Font("Serif", Font.BOLD, 30));
		join.add(name);
		ID.setBounds(230,290,200,100);
		join.add(ID);
		
		
		tId.setBounds(330,330,200,30);
		join.add(tId);
		
		JLabel Pw=new JLabel("PW");
		Pw.setFont(new Font("Serif", Font.BOLD, 30));
		join.add(name);
		Pw.setBounds(230,360,200,100);
		join.add(Pw);
		
		JButton re=new JButton("�ߺ�Ȯ��");
		re.setBackground(Color.pink);
		re.setFont(new Font("Serif", Font.BOLD, 15));
		join.add(re);
		re.addActionListener(this);
		re.setBounds(530,330,100,30);
		
		
		tPw.setBounds(330,400,200,30);
		join.add(tPw);
		
		JLabel major1=new JLabel("1st Major");
		major1.setFont(new Font("Serif", Font.BOLD, 30));
		major1.setBounds(185,440,200,100);
		join.add(major1);
		
		
		major_1.setBounds(330,470,200,30);
		join.add(major_1);
		
		JLabel major2=new JLabel("2nd Major");
		major2.setFont(new Font("Serif", Font.BOLD, 30));
		major2.setBounds(180,520,200,100);
		join.add(major2);
		
		
		t2major.setBounds(330,550,200,30);
		join.add(t2major);
		
		JButton Join=new JButton("Ok");
		Join.setBackground(Color.pink);
		Join.setFont(new Font("Serif", Font.BOLD, 30));
		Join.addActionListener(this);
		Join.setBounds(300,650,200,50);
		join.add(Join);
		
		JButton back=new JButton("��");
		back.setBackground(Color.white);
		back.setFont(new Font("Serif", Font.BOLD, 20));
		join.add(back);
		back.addActionListener(this);
		back.setBounds(0,900,100,50);
		
		jp.add("two",join);
		
		/****������ ������********/
		JPanel ad=new JPanel();
		ad.setBounds(0, 0, 800, 1000);
		ad.setLayout(null);
		ad.setBackground(Color.white);
		
		JLabel adminU=new JLabel("Administrator");
		adminU.setBounds(0,0,800,200);
		adminU.setFont(new Font("Serif", Font.BOLD, 90));
		ad.add(adminU);
		
		
		JButton sc=new JButton("Search");
		sc.setBounds(270, 200, 200,100);
		sc.setBackground(Color.pink);
		ad.add(sc);
		sc.addActionListener(this);
		sc.setFont(new Font("Serif", Font.BOLD, 40));
		

		
		
		jp.add("four",ad);
		/**********������ Ȯ�� ������********/
		
		JPanel ip=new JPanel();
		ip.setBackground(Color.white);
		ip.setBounds(0, 0, 800, 1000);
		ip.setLayout(null);
		
		ip.setBackground(Color.white);
		ip.setBounds(0, 0, 800, 1000);
		ip.setLayout(null);
		
		JLabel ida=new JLabel("ID");
		JLabel pwa=new JLabel("PW");
		
		ida.setFont(new Font("Serif", Font.BOLD, 30));
		pwa.setFont(new Font("Serif", Font.BOLD, 30));
		
		
		
		idla.setBounds(300,300,200,30);
		pwla.setBounds(300,350,200,30);
		
		ip.add(idla);
		ip.add(pwla);
		
		ida.setBounds(250,260,150,100);
		pwa.setBounds(250,310,150,100);
		
		ip.add(ida);
		ip.add(pwa);
		
		JButton ok=new JButton("Confirm");
		ok.addActionListener(this);
		ok.setBounds(300,500,180,50);
		ok.setBackground(Color.pink);
		ok.setFont(new Font("Serif", Font.BOLD, 30));
		ip.add(ok);
			

		
		jp.add("five",ip);
		
		add(jp);
	
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e)
	{
		ids=idl.getText();
		pws=pwl.getText();
		
		
		if(e.getActionCommand()=="Join")
		{
			cards.show(jp,"two");
		}
		
		else if(e.getActionCommand()=="Ok")
		{
			String name=tName.getText();
			String num=sNum.getText();
			String id=tId.getText();
			String pw=tPw.getText();
			String m1=major_1.getText();
			String m2=t2major.getText();
			
			if(name.length()==0||num.length()<8||id.length()==0||pw.length()<4||m1.length()==0)
				JOptionPane.showMessageDialog(this, "�ʼ��׸��� ä���ּ���!", "!", JOptionPane.PLAIN_MESSAGE);
			else if(count!=1)
				JOptionPane.showMessageDialog(this, "Id �ߺ� Ȯ���� ���ּ���!", "!", JOptionPane.PLAIN_MESSAGE);
			else if(name!=null&&num!=null&&id!=null&pw!=null&&m1!=null&&m2!=null&&count==1)
				try {
					State.s.executeUpdate("INSERT INTO login VALUES ('"+name+"','"+num+"','"+id+"','"+pw+"','"+m1+"','"+m2+"')");
					JOptionPane.showMessageDialog(this, "���� �Ϸ�!", "�Ϸ�", JOptionPane.PLAIN_MESSAGE);
					count=0;
					cards.show(jp, "one");
					tName.setText(null);
					sNum.setText(null);
					tId.setText(null);
					tPw.setText(null);
					major_1.setText(null);
					t2major.setText(null);
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if(name!=null&&num!=null&&id!=null&&pw!=null&&m1!=null&&m2==null&&count==1) 
				try {
					State.s.executeUpdate("INSERT INTO login (name,stNum,id,pw,1major) VALUES ('"+name+"','"+num+"','"+id+"','"+pw+"','"+m1+"')");
					JOptionPane.showMessageDialog(this, "���� �Ϸ�!", "�Ϸ�", JOptionPane.PLAIN_MESSAGE);
					count=0;
					cards.show(jp, "one");
					tName.setText(null);
					sNum.setText(null);
					tId.setText(null);
					tPw.setText(null);
					major_1.setText(null);
					t2major.setText(null);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
		
		}
		
		else if(e.getActionCommand()=="�ߺ�Ȯ��")
		{
			idj=tId.getText();
			try {
				State.rs=State.s.executeQuery("SELECT * FROM login WHERE id='"+idj+"'");
				if(State.rs.next())
				{
					if(count==1)
						count=0;
					JOptionPane.showMessageDialog(this, "�̹� �����ϴ� id�Դϴ�", "����", JOptionPane.PLAIN_MESSAGE);
				}	
				else
				{
					if(count==1)
						count=0;
					JOptionPane.showMessageDialog(this, "��� ������ id�Դϴ�", "", JOptionPane.PLAIN_MESSAGE);
					count++;
					System.out.println(count);
				}
					
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
		else if(e.getActionCommand()=="��")
		{
			cards.show(jp, "one");
			tName.setText(null);
			sNum.setText(null);
			tId.setText(null);
			tPw.setText(null);
			major_1.setText(null);
			t2major.setText(null);
		}
		
		else if(e.getActionCommand()=="Logout")
		{
			int i =JOptionPane.showConfirmDialog(null,"�α׾ƿ� �Ͻðڽ��ϱ�?", "",JOptionPane.OK_CANCEL_OPTION,JOptionPane.INFORMATION_MESSAGE);
			if(i==0)
			{
				idl.setText(null);
				pwl.setText(null);
				cards.show(jp,"one");
				
				}
			
		}
		else if(e.getActionCommand()=="Login")
		{

			
			try {
				
				State.rs=State.s.executeQuery("SELECT * FROM login WHERE id='"+ids+"' AND pw='" +pws+ "'");
				System.out.println(ids+""+pws);
				if(State.rs.next())
				{
					cards.show(jp, "three");
					tNameC.setText(State.rs.getString("name"));
					sNumC.setText(State.rs.getString("stNum"));
					tIdC.setText(State.rs.getString("id"));
					tPwC.setText(State.rs.getString("pw"));
					major_1C.setText(State.rs.getString("1major"));
					t2majorC.setText(State.rs.getString("2major"));
					
					
				}
				else
					JOptionPane.showMessageDialog(null,"��й�ȣ Ʋ�� Ȥ�� ���̵� �������� ����!","����",JOptionPane.WARNING_MESSAGE);
				
			} 
	            catch(SQLException sqlex)
				{
	                while (sqlex != null){
	                   System.err.println("SQL error: " +sqlex.getMessage());
	                   System.err.println("SQL state : " + sqlex.getSQLState());
	                   System.err.println("cause: "+sqlex.getCause());
	                   sqlex = sqlex.getNextException();
	                }
	             }   
			
			
			}
		
		else if(e.getActionCommand()=="Correct")
		{
			try {
				State.s.executeUpdate("UPDATE login SET pw='"+tPwC.getText()+"'WHERE id='"+tIdC.getText()+"'");
				State.s.executeUpdate("UPDATE login SET 1major='"+major_1C.getText()+"'WHERE id='"+tIdC.getText()+"'");
				State.s.executeUpdate("UPDATE login SET 2major='"+t2majorC.getText()+"'WHERE id='"+tIdC.getText()+"'");
				State.s.executeUpdate("UPDATE login SET name='"+tNameC.getText()+"'WHERE id='"+tIdC.getText()+"'");
				State.s.executeUpdate("UPDATE login SET stNum='"+sNumC.getText()+"'WHERE id='"+tIdC.getText()+"'");
				State.s.executeUpdate("UPDATE login SET id='"+tIdC.getText()+"'WHERE id='"+tIdC.getText()+"'");
				JOptionPane.showMessageDialog(this, "�����Ǿ����ϴ�", "����", JOptionPane.PLAIN_MESSAGE);				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		else if(e.getActionCommand()=="Withdrawal")
		{
			int i =JOptionPane.showConfirmDialog(null,"���� Ż���Ͻðڽ��ϱ�?", "Ż��",JOptionPane.OK_CANCEL_OPTION,JOptionPane.INFORMATION_MESSAGE);
			if(i==0)
			{
				try {
					State.s.executeUpdate("DELETE FROM login WHERE id='"+tIdC.getText()+"'");
					JOptionPane.showMessageDialog(this, "Ż�� �Ϸ�", "Ż��", JOptionPane.PLAIN_MESSAGE);	
					idl.setText(null);
					pwl.setText(null);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				cards.show(jp,"one");
			}
			else if(i==1){}
		}
		else if(e.getActionCommand()=="Admin")
		{
			cards.show(jp, "five");
		}
			
		else if(e.getActionCommand()=="Confirm")
		{
			try {
				State.rs=State.s.executeQuery("SELECT * FROM login WHERE id='joohye97'");
				if(State.rs.next())
				{
					if(State.rs.getString("pw").equals(pwla.getText())&&State.rs.getString("id").equals(idla.getText()))
					{
						cards.show(jp,"four");
						JButton admi=new JButton("admin");
						admi.setBounds(600,0,200,50);
						cor.add(admi);
						admi.addActionListener(this);
						admi.setBackground(Color.white);
						admi.setFont(new Font("Serif", Font.BOLD, 30));
					}
						
					else 
						JOptionPane.showMessageDialog(null,"��й�ȣ�� ��ġ���� �ʽ��ϴ�","����",JOptionPane.WARNING_MESSAGE);
				}
				
				else
					JOptionPane.showMessageDialog(null,"���̵�� ��й�ȣ�� �Է����ּ���","����",JOptionPane.WARNING_MESSAGE);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		else if(e.getActionCommand()=="admin")
		{
			cards.show(jp, "four");
		}
		
		else if(e.getActionCommand()=="Search")
		{
			String msg = JOptionPane.showInputDialog("����� �̸��� �Է��ϼ���");

			try {
				State.rs=State.s.executeQuery("SELECT * FROM login WHERE name='"+msg+"'");
				if(State.rs.next())
				{
					cards.show(jp, "three");
					tNameC.setEditable(true);
					sNumC.setEditable(true);
					tIdC.setEditable(true);
					tNameC.setText(State.rs.getString("name"));
					sNumC.setText(State.rs.getString("stNum"));
					tIdC.setText(State.rs.getString("id"));
					tPwC.setText(State.rs.getString("pw"));
					major_1C.setText(State.rs.getString("1major"));
					t2majorC.setText(State.rs.getString("2major"));
				}
				else 
					JOptionPane.showMessageDialog(null,"����ڰ� �������� �ʽ��ϴ�","����",JOptionPane.WARNING_MESSAGE);
					
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
	}
		
		
	
	public static void main(String[] args)
	{
		Project4 pj=new Project4();
	}
	
}


